﻿Giai nen Alfresco-Encryption-Module version 1.0.zip duoc hai thu muc alfresco va share
Copy va replace ca hai thu muc vao thu muc trong "./tomcat/webapps/"

Extract Alfresco-Encryption-Module version 1.0.zip to two folders "alfresco" and "share"
Copy and replace both of them into folder installed alfresc: "./tomcat/webapps/"



